//package com.pluralsight.model;
//
//import org.zkoss.bind.annotation.Command;
//import org.zkoss.bind.annotation.Init;
//
//public class MyViewModel {
//
//	@Init
//	public void init() {
//
//	}
//
//	@Command
//	public void cmd() {
//
//	}
//}
